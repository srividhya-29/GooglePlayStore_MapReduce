import pandas as pd

playStoreApps = pd.read_csv("E:\\dataIntensive\\google-play-store-apps (1)\\googleplaystore")